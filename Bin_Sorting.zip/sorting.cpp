#include <iostream>
using namespace std;

#include <string>
#include <stdlib.h>
#include <algorithm>
#include <time.h>
#include <vector>
#include "sorting.h"
#include "apvector.h"


int listSize = 200;
int d = 6;

///******************* Object Constructor ***********
Sort::Sort() {

    cout << "Choose List Size ( <30 Ideal): ";
    cin >> listSize;
    if (listSize > 200)
    {
        listSize = 200;
        cout << "listSize adjusted to 200;" << endl;
    }
    cout << endl;
    srand(time(0));
    for(int i= 0; i < listSize; i++) {
        int number = rand()%listSize + 1;
        //int number = listSize - i - 1;
        array.push_back(number);
    }
}

Sort::~Sort() {
//Destructor
    cout << "\nDeleting Object..." << endl;
}

///******************* Methods: *********************

void Sort::printArray() {
    cout << "\n\nResult Array: ";
    for (int i = 0; i < listSize; i ++) {
        cout << array[i] << " ";
    }
    cout << "\nLength of Apvector: " << array.size() << endl;
}

