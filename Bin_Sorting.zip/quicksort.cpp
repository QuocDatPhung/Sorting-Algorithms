#include <iostream>
using namespace std;

#include <string>
#include <stdlib.h>
#include <time.h>
#include <vector>
#include "sorting.h"
#include "apvector.h"

/* I have a bit of trouble coding this so I used
some reference code to help me.

Pseudocode came from:
https://www.youtube.com/watch?v=COk73cpQbFQ
and...
https://www.youtube.com/watch?v=3Bbm3Prd5Fo*/

void display(vector<int> array, int unsigned position);
 void print(vector<int> array);
///Partition Function
void part(vector<int> &array, int start, int end, int &p) {
    int pivot = array[end];
    int pIndex = start;
    int temp = 0;
    //use pivot to get partition
    for(int i = start; i< end; i++) {
        if (array[i] <= pivot) {
            temp = array[i];
            array[i] = array[pIndex];
            array[pIndex] = temp;
            pIndex+=1;
        }
    }
    //swap
    temp = array[pIndex];
    array[pIndex] = array[end];
    array[end] = temp;
    p = pIndex;
}

///QuickSort
void quicksort(vector<int> &array, int start, int end) {
    int p = 0; //pivot
    //base case
    if (start < end) {
        part(array, start, end, p);
        //display here
        display(array, end);
        quicksort(array, start, p-1);
        //display here
        display(array, end);
        quicksort(array, p+1, end);
        //display here
        display(array, end);
    }
}

///Temp Function
void Sort::callquick() {
    quicksort(array, 0, array.size() - 1);
}
