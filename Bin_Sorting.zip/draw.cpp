#include <iostream>
using namespace std;

#include <string>
#include <stdlib.h>
#include <time.h>
#include <vector>
#include "sorting.h"
#include "apvector.h"
#include <allegro5/allegro.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro_image.h>

#define BLUE     al_map_rgb(17,30,108)
#define WHITE    al_map_rgb(255, 255, 255)
#define RED      al_map_rgb(176,12,12)
#define BLACK      al_map_rgb(0,0,0)

void display(vector<int> array, int unsigned position) {
    //reset background
    al_clear_to_color(BLACK);
    //draw blocks
    for (unsigned int i = 0; i < array.size(); i++) {
        //red block shows where the program is sorting
        if (i == position) {
            al_draw_rectangle(d * i + 30, 720, d * i + d+ 30, 720 - array[i] * 3, RED, d);
        } else {
        //other blocks
            al_draw_rectangle(d * i + 30, 720, d * i + d+ 30, 720 - array[i] * 3, GREEN, d - 1);
        }

    }
    al_rest(1/100);
    al_flip_display();
}

void print(vector<int> array)
{
    cout << "\n\t";
    for (int i = 0; i < listSize; i ++){
    cout << array[i] << " ";
    }
}
