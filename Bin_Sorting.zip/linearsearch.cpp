#include <iostream>
using namespace std;

#include <string>
#include <stdlib.h>
#include <algorithm>
#include <time.h>
#include <vector>
#include "sorting.h"
#include "apvector.h"

void display(vector<int> array, int unsigned position);
 void print(vector<int> array);
int linearsearch(vector<int> array, int size, int target) {
    /*Very straightforward:
    Search for the target number, return index
    Else, return -1 index if it's not in here */
    int result = 0;
    for (int i = 0; i < size; i++) {
        if (array[i] == target) {
            result = i;
            break;
        } else {
            result = -1;
        }
    }
    return result;
}


void Sort::calllinear() {
    sort(array.begin(), array.end());
    int target = 0;
    cout << "\nArray Sorted, enter number to search: ";
    cin >> target;
    int result = linearsearch(array, array.size(), target);
    if (result == -1) {
        cout << "\nNumber not found\n";
    } else {
        cout << "\nNumber found at index " << result;
    }
    display(array, result);
}
