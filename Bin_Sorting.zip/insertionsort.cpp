#include <iostream>
using namespace std;

#include <string>
#include <stdlib.h>
#include <time.h>
#include <vector>
#include "sorting.h"
#include "apvector.h"
void display(vector<int> array, int unsigned position);

void Sort::insertionsort() {

    /* Pseudocode came from:
    https://www.youtube.com/watch?v=JU767SDMDvA */
    int temp;
    int unsorted = array.size();

    for (int i = 1; i < unsorted; i++) {
        int j = i;

        //swap in place
        //small elements sort to the start of array
        while (j > 0 && array[j-1] > array[j]) {
            //if too many vectors then program is slow
            // less than 100 is ideal.
            if (array.size() <= 30)
                print(array);
            //display first
            display(array, j);
            temp = array[j];
            array[j] = array[j-1];
            array[j-1] = temp;
            j--;
        }
        //no need to decrease unsorted.
    }

    /* Summary:
    Insertion Sort:
    1. for loop
    2. j = i;
    3. while (j>0 && array[j-1] > array[j]
    4. Swap, j--;
    */

}
