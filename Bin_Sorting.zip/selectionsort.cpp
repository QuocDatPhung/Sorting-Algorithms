#include <iostream>
using namespace std;

#include <string>
#include <stdlib.h>
#include <algorithm>
#include <time.h>
#include <vector>
#include "sorting.h"
#include "apvector.h"

void display(vector<int> array, int unsigned position);

void Sort::selectionsort() {

    /* Explanation:
    To to selection sort, it requires a temporary variable
    and the number of unsorted elements in the array.
    */
    int temp;
    int not_Sorted = array.size();
    int totalSwaps = 0;
    int totalComparisons = 0;
    int totalPasses = 0;

    /*
    Let the number of unsorted elements be the size of the array.
    Let the temporary element be used to swap elements.

    A while loop exists to keep sorting until the number
    of unsorted elements reaches a minimal amount.

    The sorting process compares two elements for each step.
    Therefore the condition of unsorted elements has to
    be greater than 1.

    5 4 3 2 1
    */
    while (not_Sorted > 1) {
        //left element
        int i = 0;
        //right element
        int j = 0;
        //increment number of passes
        totalPasses++;
        for (j = 0; j < not_Sorted; j++) {
            /*
            pretend that the 0th element
            is the largest. Run through the array
            and i changes if there is an element larger
            than the 0th element.
            */
            if(array[i] < array[j])
                i = j;
            //increment number of comparisons
            totalComparisons++;
        }
        //if too many vectors then program is slow
        // less than 100 is ideal.
        if (array.size() <= 30)
            print(array);
        //display first
        display(array, j);
        //swap the element and bring it to the end of array.
        temp = array[i];
        array[i] = array[not_Sorted-1];
        array[not_Sorted-1] = temp;
        totalSwaps++;
        //decrease not_sorted
        not_Sorted--;
    }

    cout << endl << endl;
    cout << "Total Swaps: " << totalSwaps << endl;
    cout << "Total Passes: " << totalSwaps << endl;
    cout << "Total Comparisons: " << totalComparisons << endl;

    /*Summary:
    Selection Sort:
        1. While loop > 1
        2. Get the max value
        3. Sorted always placed at the end (largest)
        4. Decrease unsorted.
    */

}
