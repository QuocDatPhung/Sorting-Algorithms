#include <iostream>
using namespace std;

#include <string>
#include <stdlib.h>
#include <time.h>
#include <vector>
#include "sorting.h"
#include "apvector.h"
#include <allegro5/allegro.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro_image.h>

#define BLUE     al_map_rgb(17,30,108)
#define WHITE    al_map_rgb(255, 255, 255)
#define RED      al_map_rgb(176,12,12)


void display(vector<int> array, int unsigned position);

void Sort::bubblesort() {
    int temp;
    int swapped = 1;
    int totalSwaps = 0;
    int totalComparisons = 0;
    int totalPasses = 0;
    int unsorted = array.size();

    /*if array is sorted there would be no swapped
    then exit while loop */
    while (swapped != 0) {
        //reset swap to 0
        swapped = 0;
        totalPasses++;
        /*swap elements next to each other
        if they are not in ascending order */
        // al_draw_rectangle(0, 0, 1280, 720, BLUE, 1000);
        for (int i=1; i<unsorted; i++) {
            /*always compare i to the element
            before that. If we compare i to the
            element after it, a problem occurs:
            When i is < unsorted, it will compare to
            i = sorted, causing program to hang */
            if(array[i-1] > array[i]) {
                //if too many vectors then program is slow
                // less than 100 is ideal.
                if (array.size() <= 30)
                    print(array);
                //display first
                display(array, i);
                //swapping
                temp = array[i-1];
                array[i-1] = array[i];
                array[i] = temp;
                //increment number of swaps.
                swapped++;
                totalSwaps++;
                totalComparisons++;
            } else {
                totalComparisons++;
            }
        }
        //one element always gets sorted
        unsorted--;
    }

    cout << endl << endl;
    cout << "Total Swaps: " << totalSwaps << endl;
    cout << "Total Passes: " << totalSwaps << endl;
    cout << "Total Comparisons: " << totalComparisons << endl;

    /*Summary:
    Bubble Sort:
    1. While swapped != 0
    2. Swapped = 0;
    3. For loop i = 1, swapped ++
    4. Unsorted--;
    */

}



