/****************************************************************

Name: Bin (Quoc Dat Phung)
Teacher: Ms. Cullum
Start: May 29, 2019
Due: June 14, 2019

Sorting Project - Use Bubble, Selection, Insertion, Merge, and Quick
                sorting algorithms and display them on the screen

Relearned from this activity:
1. Arrays are automatically passed by reference into functions.
2. Include apstring.h in main and other cpp, but don't include
apstring.cpp anywhere or else it creates a redeclaration error.


****************************************************************/


#include <iostream>
using namespace std;
#include <fstream>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>
#include <vector>
#include "sorting.h"
#include "apvector.h"

#include <allegro5/allegro.h>
#include <allegro5/allegro_image.h>
#include <allegro5/allegro_font.h>
#include <allegro5/allegro_ttf.h>

#define CYAN     al_map_rgb(0,255,255)
#define WHITE    al_map_rgb(255, 255, 255)
#define YELLOW	 al_map_rgb(255, 225, 25)
#define ORANGE   al_map_rgb(255,127,80)
#define RED      al_map_rgb(176,12,12)
#define BLUE     al_map_rgb(17,30,108)

///global
extern int listSize;
const int SCREEN_W = 1280;
const int SCREEN_H = 720;
const float FPS = 60;


/*
struct Object
    {
        float x;
        float y;
        float dx;
        float dy;
        bool live;
        ALLEGRO_BITMAP *image;

    } N0,N1,N2,N3,N4;
*/


///prototypes
void introduction(int &option);
void displaySort(vector<int> array);
//void numbers_into_file(ofstream &outFile, Sort input);
//void receive_from_file(ifstream &inFile, Sort input);
//void displaySort(vector<int> array);



int main () {

    ///FILES - Commented out because vector is already
    ///initialized in constructor. No need for files now.
    ifstream inFile;
    ofstream outFile;
    //numbers_into_file(outFile, input);
    //receive_from_file(inFile, input);
    inFile.close();
    outFile.close();


    ALLEGRO_DISPLAY *display = NULL;
    if(!al_init()) {
        fprintf(stderr, "failed to initialize allegro!\n");
        return -1;
    }

    if(!al_init_primitives_addon()) {
        fprintf(stderr, "failed to initialize primitive addon!\n");
        return -1;
    }

    display = al_create_display(SCREEN_W, SCREEN_H);
    if(!display) {
        fprintf(stderr, "failed to create display!\n");
        return -1;
    }


    /**************************************************************/

    al_clear_to_color(BLACK);

    ///Object
    Sort object;
    displaySort(object.array);

    ///**************** INPUT ***********************
    int option = 0;
    introduction(option);
    switch(option) {
    case 1:
        object.bubblesort();
        break;
    case 2:
        object.selectionsort();
        break;
    case 3:
        object.insertionsort();
        break;
    case 4:
        object.callmerge();
        break;
    case 5:
        object.callquick();
        break;
    case 6:
        object.calllinear();
        break;
    case 7:
        object.callbinary();
        break;
    default:
        cout << "\n\t Invalid Option \n";
    }


    al_clear_to_color(BLACK);
    displaySort(object.array);

    al_destroy_display(display);

    object.printArray();



    return 0;
}

///******************************** Functions ********************
void introduction(int &option) {
    cout << "Welcome to the Sorting Program.\n";
    cout << "It sorts an apvector from a file in order from least to greatest ";
    cout << "using Bubble Sort, Selection Sort, and Insertion Sort. Only displays sorts \n";
    cout << "\t Press 1: Bubble Sort \n";
    cout << "\t Press 2: Selection Sort \n";
    cout << "\t Press 3: Insertion Sort \n";
    cout << "\t Press 4: Merge Sort \n";
    cout << "\t Press 5: Quick Sort \n";
    cout << "\t Press 6: Linear Search \n";
    cout << "\t Press 7: Binary Search \n";
    cout <<"\n\t Enter Option: ";
    cin >> option;
}

void displaySort(vector<int> array) {
    for (unsigned int i = 0; i < array.size(); i++) {

        al_draw_rectangle(d * i+ 30, 720, d * i + d+ 30, 720 - array[i] * 3, GREEN, d - 1);
    }
    al_flip_display();
    al_rest(1.3);
}




/*
void numbers_into_file(ofstream &outFile, Sort input)
{


    //opening file
    outFile.open("numbers.txt");
    //if file fails to open...
    if(!outFile){
        cout << "Can't open file!";
    } else {
        //randomize numbers into file
        srand(time(0));
        for(int i=0; i<listSize; i++)
        {
            //outFile << rand()%listSize + 1 << endl;
            outFile << input.array[i];
        }
    }
}

void receive_from_file(ifstream &inFile, Sort input)
{
    //opening file
    inFile.open("numbers.txt");
    //if file fails to open...
    if(!inFile){
        cout << "Can't open file!";
    }
    //transfer data into array
    else {
        for (int i = 0; i< listSize; i++)
        {
            inFile >> input.array[i];
        }
    }
}
*/


