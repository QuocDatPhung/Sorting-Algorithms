#include <iostream>
using namespace std;


#include "sorting.h"
#include <string>
#include <stdlib.h>
#include <algorithm>
#include <time.h>
#include <vector>
#include "apvector.h"

void display(vector<int> array, int unsigned position);
 void print(vector<int> array);
void combine(vector<int> &array, int start, int middle, int end) {

    /*  Size of left array
    Added to one because or else size is smaller than it should */
    int sizeLeft = middle - start + 1; //rounded down
    /* Size of right array */
    int sizeRight = end - middle;

    /* Initializing our two arrays*/
    vector<int> L(sizeLeft);
    vector<int> R(sizeRight);

    //Transfer data from array to new left array (start -> middle)
    for (int i = 0; i < sizeLeft; i++) {
        L[i] = array[start + i];
    }

    //Transfer data from array to new right array (middle + 1 -> end)
    for (int j = 0; j<sizeRight; j++) {
        R[j] = array[middle + 1 + j];
    }

    int i = 0, j = 0;
    /* Sorting by comparing the elements between two arrays
    Keep doing this until each array is sorted */
    while(i <= sizeLeft - 1 && j <= sizeRight - 1) {
        /* If the left element is smaller than the right element
          Then we take it and put it as first element of our original array.
          It's okay to modify our original array directly in this case*/
        if (L[i] <= R[j]) {
            array[start] = L[i];
            i++;
        } else {
            array[start] = R[j];
            j++;
        }
        //add to start to move to next element of our original array
        start++;
    }
    /* At one time, the left or right array will run out of
    elements to compare and therefore exists the while loop.
    However, this still means that the other array still has
    some elements left. So below we make sure that they get
    sorted as well. Because the left or right array is sorted,
    only one of the below while loops will run */

    while (i <= sizeLeft - 1) {
        array[start] = L[i];
        i++;
        start++;
    }

    while (j <= sizeRight - 1) {
        array[start] = R[j];
        j++;
        start++;
    }
}

void mergesort(vector<int> &array, int start, int end) {

    /* Recursive Method for MergeSort */
    //Base case: The index of "end" should not be equal to "start"
    //This is where we stop dividing the array
    if (start < end) {

        /*
        - middle index: always rounded down
        - for example, if array size is 6, "middle" would
         be 3

        Later on, when we do recursion, the array will be
        choped into two subarrays, which would be chopped
        again because of recursion.

        It's ok if size is odd. In the end, it will be
         chopped so much that it doesn't matter and the
          result is the same.

        Array Example (5 elements):
        0 1 2 3 4 5

        L goes from start to middle
        R goes from middle + 1 until the end

        middle = start + (end - start)/2
        To get middle = 0 + (6-0)/2 = 3

        L Array                         R Array
        0 1 2                           3 4 5

        Chopping L again with recursion:
        middle = 0 + (3 - 0)/2 = 1 (rounded down, index 1
        which means second element in the array.)

        Chopping R with recursion:
        middle = 3 + (6 - 3)/2 = 1 (index 1, which is 4)

        This results in this formula:
        */
        int middle = start + (end-start)/2;

        //RECURSION PART
        mergesort(array, start, middle);
        //display here
        display(array, end);
        mergesort(array, middle + 1, end);
        //display here
        display(array, end);
        //Combine arrays together
        combine (array, start, middle, end);
        //display here
        display(array, end);
    }
}


void Sort::callmerge() {
    mergesort(array, 0, array.size() - 1);
}
