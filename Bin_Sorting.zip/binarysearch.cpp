#include <iostream>
using namespace std;

#include <string>
#include <stdlib.h>
#include <algorithm>
#include <time.h>
#include <vector>
#include "sorting.h"
#include "apvector.h"

void display(vector<int> array, int unsigned position);
 void print(vector<int> array);
int binarysearch(vector<int> &array, int start, int end, int target) {
    /* I didn't know how to do this recursively
    so I had some help from:
    https://www.geeksforgeeks.org/binary-search/
    I did not copy and paste but I tried to learn it. */

    //base case: make sure the array is feasible first
    if (start <= end) {
        int middle = start + (end - start)/2;

        //if the element is found as the middle
        if (array[middle] == target) {
            return middle;
        }

        //if target < middle
        if (target < array[middle]) {
            return binarysearch(array, start, middle - 1, target);
        }

        //if target > middle
        if (target > array[middle]) {
            return binarysearch(array, middle + 1, end, target);
        }
    }
    return -1;
}


void Sort::callbinary() {
    sort(array.begin(), array.end());
    int target = 0;
    cout << "\nArray Sorted, enter number to search: ";
    cin >> target;
    int result = binarysearch(array, 0, array.size()-1, target);
    if (result == -1) {
        cout << "\nNumber not found\n";
    } else {
        cout << "\nNumber found at index " << result;
    }
    display(array, result);
}
