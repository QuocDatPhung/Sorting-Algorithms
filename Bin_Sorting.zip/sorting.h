#ifndef SORTING_H_INCLUDED
#define SORTING_H_INCLUDED
#define CYAN     al_map_rgb(0,255,255)
#define GREEN    al_map_rgb(0,128,0)
#define WHITE    al_map_rgb(255, 255, 255)
#define BLACK    al_map_rgb(0,0,0)
#define YELLOW	 al_map_rgb(255, 225, 25)
#define ORANGE   al_map_rgb(255,127,80)
#define RED      al_map_rgb(176,12,12)

#include <allegro5/allegro.h>
#include <allegro5/allegro_primitives.h>
#include <allegro5/allegro_image.h>

#include <vector>
#include "apvector.h"


extern int listSize;
extern int d;

class Sort {

public:
    ///CONSTRUCTORS
        //overloading MyCircle
        Sort();
        ~Sort();

    ///METHODS
        void printArray();
        void selectionsort();
        void bubblesort();
        void insertionsort();
        void callmerge();
        void callquick();
        void calllinear();
        void callbinary();

        void print(vector<int> array)
        {
            cout << "\n\t";
            for (int i = 0; i < listSize; i ++){
            cout << array[i] << " ";
            }
        }

vector<int> array;

private:

};

#endif // SORTING_H_INCLUDED


